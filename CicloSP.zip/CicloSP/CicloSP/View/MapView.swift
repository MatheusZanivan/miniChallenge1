//
//  MapView.swift
//  CicloSP
//
//  Created by Barbara de Argolo Melo on 23/09/22.
//
import MapKit
import SwiftUI
import CoreLocation

enum MapDetails {
    
    static let startingLocation = CLLocationCoordinate2D(latitude: 37.331516, longitude: 121.891054)
    static let defaultSpan = MKCoordinateSpan(latitudeDelta: 0.03, longitudeDelta: 0.03)
    
    static let localizacaoUsuario = CLLocationCoordinate2D(latitude: -23.678157740575077, longitude: -46.69814935895259)
    static let localizacaoCiclovia = CLLocationCoordinate2D(latitude: -23.57, longitude: -46.70)
    
}

struct mapView: UIViewRepresentable {
    
    let region: MKCoordinateRegion
      
       @Binding var locationManager: CLLocationManager
       @Binding var showMapAlert: Bool
    let map = MKMapView()
    
    func makeUIView(context: UIViewRepresentableContext<mapView>) -> MKMapView {
        
        
        let region = MKCoordinateRegion(center: MapDetails.localizacaoUsuario, span: MapDetails.defaultSpan)
        
        
        let sourcePin = MKPointAnnotation()
        sourcePin.coordinate = MapDetails.localizacaoUsuario
        sourcePin.title = "Início"
        map.addAnnotation(sourcePin)
        
        let destinationPin = MKPointAnnotation()
        destinationPin.coordinate = MapDetails.localizacaoCiclovia
        destinationPin.title = "Destino"
        map.addAnnotation(destinationPin)
        
        map.region = region
        map.delegate = context.coordinator
        
        let req = MKDirections.Request()
        req.source = MKMapItem(placemark: MKPlacemark(coordinate: MapDetails.localizacaoUsuario))
        req.destination = MKMapItem(placemark: MKPlacemark(coordinate: MapDetails.localizacaoCiclovia))
        
        let directions = MKDirections(request: req)
        
        directions.calculate { (direct, err) in
            
            if err != nil {
                print((err?.localizedDescription) as Any)
                return
            }
            
            let polyline = direct?.routes.first?.polyline
            map.addOverlay(polyline!)
            map.setRegion(MKCoordinateRegion(polyline!.boundingMapRect ), animated: true)
        }
        return map
    }
    
    func updateUIView(_ uiView: MKMapView, context: UIViewRepresentableContext<mapView>) {
        map.showsUserLocation = true
        map.userTrackingMode = .follow

        
        let coordinate = CLLocationCoordinate2D(latitude:-23.6699, longitude: -46.7012)
        let span = MKCoordinateSpan(latitudeDelta: 0.015, longitudeDelta: 0.015)
        let region = MKCoordinateRegion(center: uiView.userLocation.location?.coordinate ?? coordinate, span: span)
        uiView.setRegion(region, animated: true)
                         
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }
    

    
    
    class Coordinator: NSObject, MKMapViewDelegate, CLLocationManagerDelegate {
        
        var parent: mapView

        init(_ parent: mapView) {
          self.parent = parent
        }

        
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            
            let render = MKPolylineRenderer(overlay: overlay)
            render.strokeColor = .blue
            render.lineWidth = 4
            return render
        }
        
    }
    
}




