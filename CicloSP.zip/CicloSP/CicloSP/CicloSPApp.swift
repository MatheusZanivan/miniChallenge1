//
//  CicloSPApp.swift
//  CicloSP
//
//  Created by Barbara de Argolo Melo on 23/09/22.
//

import SwiftUI

@main
struct CicloSPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
